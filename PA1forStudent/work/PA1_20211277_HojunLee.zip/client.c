/*
** client.c -- a stream socket client demo
*/

// https://reakwon.tistory.com/107 getopt

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netinet/in.h> // 엔디안 바꾸는거 정의되어 있음. ntohs(), ntohl(), htons(), htonl()
#include <stdbool.h>


#include <arpa/inet.h>

// #define PORT "3490" // the port client will be connecting to 

#define MAXDATASIZE 10000000 // max number of bytes we can get at once

int send_byte(int sockfd, char *buf, size_t len) {
    size_t total_sent = 0;
    while (total_sent < len) {
        ssize_t sent_now = send(sockfd, buf + total_sent, len - total_sent, 0);
        total_sent += sent_now;
    }
    return 0;
}

int recv_byte(int sockfd, char *buf, size_t len) {
    size_t total_received = 0;
    while (total_received < len) {
        ssize_t received_now = recv(sockfd, buf + total_received, len - total_received, 0);
        total_received += received_now;
    }
    return 0;
}


void parse_msg(char* msg, char* op, uint16_t* key_length, uint32_t* data_length, char** key, char** txt) {
    char* ptr = msg;

    *op = *ptr;
    ptr += 2;

    memcpy(key_length, ptr, 2);
    *key_length = ntohs(*key_length);
    ptr += 2;

    memcpy(data_length, ptr, sizeof(uint32_t));
    *data_length = ntohl(*data_length);
    ptr += 4;

    *key = (char*)ptr;
    *txt = (char*)ptr + *key_length;
}

size_t create_msg(char op, u_int16_t keylen, u_int32_t datalen, char* to, char* key, char* txt){
	size_t i=0;
	uint16_t* key_length;
	uint32_t* data_length;
	memset(to, 0, MAXDATASIZE);
	
	to[i]= op; // op 1byte
	i+=2;

	key_length = (uint16_t*)(to+i);
	*(key_length) = htons(keylen);
	i+=2;

	data_length = (uint32_t*)(to+i);
	*(data_length) = datalen;
	*(data_length) = htonl(datalen);
	i+=4;

	memcpy( to+i ,key,keylen);
	i+=keylen;


	memcpy(to+i ,txt, datalen);
	i+=datalen;
	return i;
}


// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	if (sa->sa_family == AF_INET) {
		return &(((struct sockaddr_in*)sa)->sin_addr);
	}

	return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main(int argc, char *argv[])
{
    char *host = NULL;
    char* port = 0;
    int operation = -1;
    char *key = NULL;
	uint16_t key_len=0;

    int opt;

    // getopt 루프: 더 이상 처리할 옵션이 없을 때까지
	//https://velog.io/@naive/getopt-%EC%82%AC%EC%9A%A9%EB%B2%95
    while ((opt = getopt(argc, argv, "h:p:o:k:")) != -1) {
        switch (opt) {
            case 'h':
                host = optarg;
                break;
            case 'p':
                port = optarg; 
                break;
            case 'o':
                operation = atoi(optarg);
                break;
            case 'k':
                key = optarg;
                break;
            default:
                exit(EXIT_FAILURE);
        }
    }

    // 필수 인자가 모두 입력되었는지 확인
    if (host == NULL || port == 0 || operation == -1 || key == NULL) {
        exit(EXIT_FAILURE);
    }

	key_len = strlen(key);
	char* PORT = port;
// ------------------------------------------------------ 파싱 끝




	int sockfd, numbytes;
	char *buf = (char*) malloc(MAXDATASIZE);
	char *msg = (char*) malloc(MAXDATASIZE);
	struct addrinfo hints, *servinfo, *p;
	int rv;
	char s[INET6_ADDRSTRLEN];

	// if (argc != 2) {
	//     fprintf(stderr,"usage: client hostname\n");
	//     exit(1);
	// }

	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;

	if ((rv = getaddrinfo(host, PORT, &hints, &servinfo)) != 0) {
		fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
		return 1;
	}

	// loop through all the results and connect to the first we can
	for(p = servinfo; p != NULL; p = p->ai_next) {
		if ((sockfd = socket(p->ai_family, p->ai_socktype,
				p->ai_protocol)) == -1) {
			perror("client: socket");
			continue;
		}

        inet_ntop(p->ai_family,
            get_in_addr((struct sockaddr *)p->ai_addr),
            s, sizeof s);
        // printf("client: attempting connection to %s\n", s);

		if (connect(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
			perror("client: connect");
			close(sockfd);
			continue;
		}

		break;
	}

	if (p == NULL) {
		fprintf(stderr, "client: failed to connect\n");
		return 2;
	}

	inet_ntop(p->ai_family,
			get_in_addr((struct sockaddr *)p->ai_addr),
			s, sizeof s);
	// printf("client: connected to %s\n", s);

	freeaddrinfo(servinfo); // all done with this structure


	size_t len_read;

	while( (len_read = fread(buf, 1, MAXDATASIZE - 8 - key_len, stdin)) > 0 ){ //주의 recv 로 한번에 다 안받을 수도 있어서 여러번 반복해야함.
		size_t msg_len;
		msg_len = create_msg(operation, key_len,len_read, msg, key,buf);
		// printf("keylen : %hu\n", key_len);

		if ( send_byte(sockfd, msg, msg_len) == -1 ){
			break;
		}

		// 받을때는 헤더 먼저 받고
		char op;
		uint16_t key_length;
		uint32_t data_length;
		// char* key;
		char* txt;

		size_t total_received = 0;
		size_t received = 0;
		
		recv_byte(sockfd, buf, 8);

		memcpy(&op, buf, 1);
		memcpy(&key_length, buf+2, 2);
		memcpy(&data_length, buf+4, 4);

		key_length = ntohs(key_length);
		data_length = ntohl(data_length);

		recv_byte(sockfd, buf, key_length + data_length);
		fwrite(buf + key_length, 1, data_length, stdout);
	}

	close(sockfd);

	return 0;
}